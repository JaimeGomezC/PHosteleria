<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Reservas Hostelería La Flota</title>
</head>
<body>
    <h1>Estimado/a cliente</h1>
    
    <p>{!! $demo->mensaje !!}</p>
</body>
</html>
